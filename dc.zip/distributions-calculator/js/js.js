function plot(dd, title, xLbl, yLbl) {
    var dps = []; // dataPoints
    var dp11 = []; // dataPoints
    var chart = new CanvasJS.Chart("chartContainer", {
        theme: "light1",
        title: { text: title, fontcolor: "red", titleFontFamily: "tahoma", fontSize: 16, },
        legend: { verticalAlign: "top", horizontalAlign: "right" },
        axisY: { includeZero: false, gridDashType: "dot", gridThickness: 0.5, lineThickness: 2, title: yLbl },
        axisX: { includeZero: false, gridDashType: "dot", gridThickness: 0.5, lineThickness: 2, title: xLbl },
        data: [{
            type: "scatter", showInLegend: true, name: "Model", markerType: "cross", markerSize: 5, markerColor: "blue",
            legendMarkerSize: 4, dataPoints: dps, color: "red",
        },
            { type: "line", showInLegend: true, name: "1:1 Slope", dataPoints: dp11 }]
    });
    var d0 = [];
    for (var j = 0; j < dd.length; j++) {
        dps.push({
            x: dd[j][0],
            y: dd[j][1]
        });
        d0[2 * j] = dd[j][0];
        d0[2 * j] = dd[j][0];
    }
    dp11.push({ x: arrayMin(d0), y: arrayMin(d0) });
    dp11.push({ x: arrayMax(d0), y: arrayMax(d0) });
    chart.render();
    document.getElementById("save2f").addEventListener("click", function () {
        chart.exportChart({ format: "jpg" });
    });
}
function arrayMin(arr) {
    return arr.reduce(function (p, v) {
        return (p < v ? p : v);
    });
}

function arrayMax(arr) {
    return arr.reduce(function (p, v) {
        return (p > v ? p : v);
    });
}
function cite(str) {
    var controlValue = 'AgriMetSoft (2019). Online Calculators. Available on: https://agrimetsoft.com/calculators/' + str;
    window.prompt('Cite', controlValue);
}
