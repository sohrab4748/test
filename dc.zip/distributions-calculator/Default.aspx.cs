﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _calculators : System.Web.UI.Page
{
    bool mob=false;
    protected void Page_Load(object sender, EventArgs e)
    {
     Page.Title="Online Free Calculators";  
    }
    protected void page_PreInit(object sender, EventArgs e)
    {
        Page p = this.Context.Handler as Page;
        if (p != null)
        {
            // set master page
            if (Request.Browser.IsMobileDevice)
            {
                p.MasterPageFile = "~/Site.Mobile.master";
                mob = true;
                //  p.Header.Controls.Add(styleLink);
            }
        }
    }
    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
       
    }
    
    protected void add_Click(object sender, EventArgs e)
    {
       
    }
}