using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class r2 : System.Web.UI.Page
{
    bool mob = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Title = "Normal Distribution Calculator";
    }
    protected void page_PreInit(object sender, EventArgs e)
    {
        Page p = this.Context.Handler as Page;
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup", "alert(mob);", true);
        if (p != null)
        {
            // set master page
            if (Request.Browser.IsMobileDevice)
            {
                p.MasterPageFile = "~/Site.Mobile.master";
                mob = true;
                //  p.Header.Controls.Add(styleLink);
            }
        }
    }

   
}