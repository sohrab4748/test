﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.IO;
using System.Web;
using System.Net;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Site_Mobile : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
		 if (!IsPostBack)
        {
			string url = Request.Url.Host;
        string[] filePaths = Directory.GetFiles(Server.MapPath("~/"));
    List<string> pp1=new List<string>();
        int nP = 0;
        foreach (string filePath in filePaths)
        {
            if (filePath.Contains(".aspx.cs") & !filePath.Contains("add.aspx.cs") &
                !filePath.Contains("List.aspx.cs") & !filePath.Contains("Default.aspx"))
            {
                var ff = Path.GetFileName(filePath);
                int n = ff.Length;
                var fileP1 = ff.Remove(n - 8, 8) + ".aspx";
                pp1.Add(fileP1);
                var fp = Uri.EscapeUriString(fileP1);
                nP++;
            }
        }
		
			var tools= pp1.ToArray();
            var anchors = new HtmlAnchor[tools.Length];
            for (int i = 0; i < tools.Length; i++)
            {
                HtmlGenericControl LI = new HtmlGenericControl("li");
                anchors[i] = new HtmlAnchor()
                {
                    InnerText = tools[i].Replace(".aspx", "").Replace("-", " ").Replace("/", "->").Replace("\\", "->"),
                    HRef = tools[i],
                };
                LI.Controls.Add(anchors[i]);
                myUL_Top.Controls.Add(LI);

            }
        }
    }
    protected void OnMenuItemDataBound(object sender, MenuEventArgs e)
    {
        if (SiteMap.CurrentNode != null)
        {
            if (e.Item.Text == SiteMap.CurrentNode.Title)
            {
                if (e.Item.Parent != null)
                {
                    e.Item.Parent.Selected = true;
                }
                else
                {
                    e.Item.Selected = true;
                }
            }
        }
    }

}